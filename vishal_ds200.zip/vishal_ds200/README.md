# ds200
I have plotted the sex ratio of different Indian states for the year 2001 and 2011 considering rural and urban population.
The change in sex ratio is clearly more in urban areas than rural.
This shows the education difference realted to the awarness among society.
I had problem in showing the states in xaxis because the state names were large and python did not account for that.
