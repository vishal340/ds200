# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 15:43:41 2019

@author: Vishal Tripathy
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import math
from statistics import median
from matplotlib.ticker import MultipleLocator


def initialize(size):
    list_ = list()
    for i in range(0,size):
        list_.append( list() ) #different object reference each time
    return list_

data=open("State-wise-SR_2001_2011.csv","r")
state=[]

counter=0
ratio=initialize(6)

for i in data:
    var=i.split(",")
    if (counter==0):
        counter+=1
    elif counter>0:
        state.append(var[0])
        ratio[0].append(float(var[1]))
        ratio[1].append(float(var[2]))
        ratio[2].append(float(var[3]))
        ratio[3].append(float(var[4]))
        ratio[4].append(float(var[5]))
        ratio[5].append(float(var[6]))
details=['Total - 2001','Total - 2011','Rural - 2001','Rural - 2011','Urban - 2001','Urban - 2011']
marker=['o','*','^','|','_','+']
#scatter plot
plt.figure(1)
for i in range(6):
    plt.scatter(state,ratio[i],marker=marker[i],label=details[i])
plt.xlabel("country/state/union territory")
plt.ylabel("sex ratio")
plt.legend(fontsize=6)
plt.show()

#line plot
plt.figure(2)
for i in range(6):
    plt.plot(state,ratio[i],marker=marker[i],label=details[i])
plt.xlabel("country/state/union territory")
plt.ylabel("sex ratio")
plt.legend(fontsize=6)
plt.show()


#box plot
plt.figure(3)
new_list=[]
for i in range(3):
    for j in range(len(ratio[i])):
        new_list.append([ratio[2*i][j],ratio[2*i+1][j]])
    plt.boxplot(new_list,labels=state)
    new_list=[].copy()
plt.xlabel("country/state/union territory")
plt.ylabel("sex ratio")
plt.show()